<?php
// session_start();
include '../common/header.php';
?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Services</title>
  <link rel="stylesheet" href="../CSS/services.css">
  <link rel="stylesheet" href="../CSS/index.css" />
  <link rel="stylesheet" href="../CSS/AboutUs.css" />


</head>

<body>

  <h1 class="services">services</h1>
  <?php
  include '../common/service_boxs.php';
  ?>
  <?php
  include '../common/footer.php';
  ?>