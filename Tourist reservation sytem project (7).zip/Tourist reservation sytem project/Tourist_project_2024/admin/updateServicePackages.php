<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Our Services</title>
  <link rel="stylesheet" href="../CSS/dashboard.css">
  <link rel="stylesheet" href="../CSS/toursitSite.css">
</head>

body>
<?php
  include 'updateServices.php';
  include 'dashboardcommon.php';

  echo '<table class="table-admin" border="1">';
  echo "<tr>
    <td class='bold'>Service ID</td>
    <td class='bold'>Service Name</td>
    <td class='bold'>Description</td>
    <td class='bold'>Images</td>
    <td class='bold'>Edit</td>
    <td class='bold'>Delete</td>
  </tr>";

  $sql = 'SELECT * FROM services';
  $result = mysqli_query($con, $sql);
  while ($data = mysqli_fetch_array($result)) {
    $escapedTitle = addslashes($data['serv_name']);
    $escapedDescription = addslashes($data['description']);
    echo "<tr>
      <td class='data'>{$data['serv_id']}</td>
      <td class='data'>{$data['serv_name']}</td>
      <td class='data'>{$data['description']}</td>
      <td><img width='100px' height='100px' src='data:image/jpeg;base64," . base64_encode($data['serv_img']) . "'></td>
      <td class='bold'><a href='#' onclick='openEditModal({$data['serv_id']}, \"{$escapedTitle}\", \"{$escapedDescription}\")'>Edit</a></td>
      <td class='bold'><a href='#' onclick='openDeleteModal({$data['serv_id']})'>Delete</a></td>
    </tr>";
  }
  echo '</table>';
  ?>

<!-- Edit Modal -->
<div id="editModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('editModal')">&times;</span>
    <h2>Edit Service</h2>
    <form id="editServiceForm" action="editServicePackage.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" id="editServId" name="serv_id">
      <label for="editTitle">Title:</label>
      <input type="text" id="editTitle" name="title" required><br><br>
      <label for="editDescription">Description:</label>
      <textarea id="editDescription" name="description" required></textarea><br><br>
      <label for="serv_img">Image:</label>
      <input type="file" name="serv_img"><br><br>
      <button type="submit">Update</button>
    </form>
  </div>
</div>

<!-- Delete Modal -->
<div id="deleteModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('deleteModal')">&times;</span>
    <h2>Delete Service</h2>
    <p>Are you sure you want to delete this Service?</p>
    <form action="deleteService.php" method="POST">
      <input type="hidden" id="deleteServId" name="serv_id">
      <button type="submit">Yes, Delete</button>
      <button type="button" onclick="closeModal('deleteModal')">Cancel</button>
    </form>
  </div>
</div>

<script>
// Open the Edit Modal
function openEditModal(serv_id, serv_name, description) {
  console.log('Opening Edit Modal with ID:', serv_id);
  console.log('Service Name:', serv_name);
  console.log('Description:', description);

  document.getElementById('editServId').value = serv_id;
  document.getElementById('editTitle').value = serv_name;
  document.getElementById('editDescription').value = description;
  document.getElementById('editModal').style.display = 'block';
}

// Open the Delete Modal
function openDeleteModal(serv_id) {
  document.getElementById('deleteServId').value = serv_id;
  document.getElementById('deleteModal').style.display = 'block';
}

// Close any modal
function closeModal(modalId) {
  document.getElementById(modalId).style.display = 'none';
}

// Optionally, prevent the form from submitting if there's an issue with validation
document.getElementById('editServiceForm').addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent form submission to inspect data
  const title = document.getElementById('editTitle').value;
  const description = document.getElementById('editDescription').value;

  if (!title || !description) {
    alert('Please fill all required fields.');
  } else {
    // If everything is fine, submit the form
    this.submit();
  }
});

// Click outside the modal to close it
window.onclick = function(event) {
  if (event.target == document.getElementById('editModal') || event.target == document.getElementById(
    'deleteModal')) {
    closeModal('editModal');
    closeModal('deleteModal');
  }
}
</script>

</body>

</html>

</html>