<?php
session_start();
include '../../databases for tourist reservation sytem/dbconnection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashbord</title>
  <link rel="stylesheet" href="../CSS/dashboard.css">
  <link rel="stylesheet" href="../CSS/index.css">
</head>

<body>
  <section class="dashboard-container">
    <div class="aside">
      <div class="side-list">
        <div class="logo">
          <i class="fas fa-map-marker-alt"></i>
          <span>Tourist</span>
        </div>
        <ul>

          <li><a href="#">Dashboard</a></li>
          <li><a href="manageBooking.php">Bookings</a></li>
          <li><a href="newUser.php">New User</a></li>
          <li><a href="updateTourismSite.php">Update Tourist sites</a></li>
          <li><a href="updateServicePackages.php">Update Tour Service Package</a></li>
          <li><a href="#"></a></li>
          <li><a href="../index.html/index.php">Back To home</a></li>
          <li><a href="#">Logout</a></li>
        </ul>
      </div>
    </div>
    </div>

    <div class="main-dashboard">


      <div class="Welcome-to-dashboard">
        <h1>Welcome to Admin Dashboard</h1>
        <div class="profile">

          <input type="button" value="search" onclick="searchUser()">
          <span class="user">
            <span class="tourist-profile"><?php echo htmlspecialchars($_SESSION['username']); ?></span>

            <?php if (isset($_SESSION['profile_pic'])) { ?>
            <img width="100px" height="100px" src="<?php echo htmlspecialchars($_SESSION['profile_pic']); ?>"
              alt="Profile Picture" class="profile-pic">
            <?php } ?>
          </span>
          <a href="">Help</a>
        </div>
      </div>
    </div>

    <div class="dataContainer">
      <?php



function countRows($con, $tableName) {
    $query = "SELECT * FROM $tableName";
    $result = mysqli_query($con, $query);
    if ($result) {
        return mysqli_num_rows($result);
    } else {
        return 0; 
    }
}

// Fetch counts
$numUsers = countRows($con, 'users');
$numBookings = countRows($con, 'booking');
$numDestinations = countRows($con, 'locations');
$numServices = countRows($con, 'services');

mysqli_close($con);
?>

      <div class="dataContainer-main">


        <p class="userdata">Users: <span class="datanumber"><?php echo $numUsers; ?></p></span>



        <p class="bookingdata">Bookings: <span class="datanumber"><?php echo $numBookings; ?></span>

        </p>



        <p>
          <class="destionationdata">Destinations:
            <span class="datanumber"><?php echo $numDestinations; ?></span>
        </p>



        <p class="servicesdata">Services: <span class="datanumber"><?php echo $numServices; ?></span> </p>

      </div>


      <script src="../js/searchUser.js"></script>