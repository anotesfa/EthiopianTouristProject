<!DOCTYPE html>
<html lang="en">


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Bookings</title>
</head>

<body>
  <?php
include '../../databases for tourist reservation sytem/dbconnection.php';
include 'dashboardcommon.php';?>



  <h1 class="heading">Manage Bookings

  </h1>
  <?php
  
  echo'<table class="table-admin" border="1">';
  echo "<tr>
  <td class='bold'>Ticket No</td>
  <td class='bold'>Full Name</td>
  <td class='bold'>Email</td>
  <td class='bold'>Date</td>
  <td class='bold'>Destination</td>
  <td class='bold'>Package</td>
  <td class='bold'>Payment status</td>
  <td class='bold'>Special_request</td>
  </tr>
  
  ";
  $sql = 'SELECT * FROM booking';
  $result = mysqli_query ($con,$sql);
  while($data =mysqli_fetch_array($result)){
echo "<tr>
<td  class='data'>".$data['Ticket_no']."</td>

<td  class='data'>". $data['Full_name']."</td>
<td  class='data'>".$data['Email']."</td>
<td  class='data'>".$data['Date']."</td>
<td  class='data'>".$data['Destination']."</td>
<td  class='data'>".$data['Package']."</td>
<td  class='data'>".$data['Payment']."</td>
<td  class='data'>".$data['special_request']."</td>

</tr>







";

  }
  
  echo "</table>";
  
  
  
  ?>

  </div>






  </div>

  </section>
</body>

</html>