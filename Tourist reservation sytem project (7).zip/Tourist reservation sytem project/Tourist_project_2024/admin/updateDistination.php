<?php
include '../../databases for tourist reservation sytem/dbconnection.php';

$locations = [
  [
    'image' => '../../images/images/jifar.jpeg',
    'title' => 'ABBA JIFAR PALACE',
    'Price' => '250$-15000$',
    
    'catagory'=>'',
    'description' => '<div class="content">
    <h1>ABBA JIFAR PALACE</h1>
    <p>Aba Jifar Palace is the most important heritage site in the Oromia Region of Ethiopia. <span class="hidden">
        The palace is a beautiful example of traditional Ethiopian architecture and offers a fascinating glimpse into the
        history of the region. Located on the outskirts of the city of Jimma, it was built by King Aba Jifar II in the 1880s, found at 2,000 meters above sea level.
    </span></p>
  </div>',
],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'LALIBELA',
      'Price' => '220$-14000$',
      'catagory'=>'',
      'description' => 'Lalibela is a town located in the Amhara region of Ethiopia, approximately 700 kilometers north of Addis Ababa. <span class="hidden">The town is situated at an altitude of around 2,500 meters above sea level, offering a cool and pleasant climate throughout the year. Lalibela is known for its unique rock-hewn churches, which are UNESCO World Heritage sites. The surrounding landscape is characterized by rugged mountains and lush green valleys. The region is also home to endemic species such as the Ethiopian wolf and the Gelada baboon.</span>',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'AKSUM',
      'Price' => '280$-16000$',
      'catagory'=>'',
      'description' => 'Aksum symbolizes the wealth, power, and historical significance of the Aksumite Civilization. <span class="hidden">Aksum is situated in the highlands of northern Ethiopia. It was the capital of the powerful Aksumite Kingdom, which thrived from the 1st to the 8th centuries AD. Aksum sits at an impressive altitude on the Tigray Plateau, which is found about 1000km from the capital Addis Ababa. It has cooler temperatures due to the elevation.</span>',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'HARAR JUGOL',
      'Price' => '200$-13000$',
      'catagory'=>'',
      'description' => 'Located in the eastern part of the country on a hilltop at the height of 1885m, the fortified historic town of Harar Jugol is the capital city of the administrative region of Harari. <span class="hidden">Harar Jugol is located approximately 525 kilometers (326 miles) east of Addis Ababa, the capital city of Ethiopia. Harar Jugol is situated at an altitude of around 1,885 meters (6,184 feet) above sea level. Some endemic species in Harar Jugol are the Ethiopian wolf, the Walia ibex, and various birds.</span>',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'BALE MOUNTAINS NATIONAL PARK',
      'Price' => '300$-18000$',
      'catagory'=>'',
      'description' => '<div class="content">
      <p>Bale Mountains National Park is located in southeastern Ethiopia, 400 km southeast of Addis Ababa and
        150 km east of Shashamene in the Oromia Region National State.
        <span class="hidden">
          The national park contains a spectacularly diverse landscape. The high-altitude, afro-montane Sanetti Plateau rises to over 4,000m and includes the highest peak in the southern Ethiopian highlands. Bale Mountains National Park experiences a mild, wet climate.
        </span>
      </p>
    </div>',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'WENCHI CRATER LAKE',
      'Price' => '220$-12000$',
      'catagory'=>'',
      'description' => 'Wenchi Lake is a beautiful volcanic crater lake that is famed as “Africa Switzerland”, it is also
          home to natural forests, hot springs, and waterfalls, as well as a traditional village. Wenchi Lake
          is located 155 km from Addis Ababa.
          <span class="hidden">
            The landscape surrounding the lake is marked by beautiful
            highland scenery, with rolling hills. Due to its altitude of over 3,000 meters above sea level, the
            weather conditions around the lake are mild and pleasant with cooler temperatures. Whether you`re a
            fitness enthusiast or just looking to stay active while on vacation, this place is an excellent
            choice.
          </span>
        ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'SIMIEN MOUNTAINS NATIONAL PARK',
      'Price' => '250$-15000$',
      'catagory'=>'',
      'description' => 'Simien Mountains National Park is found in northern Ethiopia, Amhara region. 
        <span class="hidden">
          About 425 kilometers from Addis Ababa, the park experiences a temperate climate with cool temperatures due to its high
          elevation, ranging from 1900 to 4430 meters above sea level. The park is known for its stunning landscape
          including deep valleys, rugged mountains, and unique wildlife.
        </span>',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'ERTALE',
      'Price' => '350$-20000$',
      'catagory'=>'',
      'description' => 'Ertale is one of Africa`s few active volcanoes, standing at 613 meters (2,011 ft) high, located in the Afar region of Ethiopia, 390 kilometers from Addis Ababa, with one or sometimes two active lava lakes at the summit which occasionally overflow on the south side of the volcano. 
        <span class="hidden">
          The temperatures can reach up to 1,868 degrees Fahrenheit (1,020 degrees Celsius).
        </span>
      ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'BLUE NILE FALLS',
      'Price' => '250$-15000$',
      'catagory'=>'',
      'description' => 'Blue Nile Falls is a magnificent waterfall located in the Amhara Region of Ethiopia, found
        about 580 km from Addis Ababa.
        <span class="hidden">
          The climate around Blue Nile Falls has cooler temperatures due to its elevation. It lies approximately 30 kilometers (19 miles) downstream from the town of Bahir Dar and Lake Tana. The falls cascade down from a height of 42 meters (138 feet), and are one of Ethiopia/'.'s most renowned tourist attractions.
        </span>
     ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'SOF-OMAR CAVE',
      'Price' => '290$-17000$',
      'catagory'=>'',
      'description' => 'Sof Omar Caves is the longest cave in Ethiopia at 15.1 kilometers (9.4 mi).
        <span class="hidden">
          When surveyed in 1972, it was the longest cave in Africa. It is situated to the east of Ginnir, in the East Bale Zone
          of the Oromia Region in southeastern Ethiopia, 509.2 km from Addis Ababa. It lies at an elevation of
          1300m above sea level. The cave has many white-washed pillars, particularly in the chamber of
          columns.
        </span>
      ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'GAMBELLA NATIONAL PARK',
      'Price' => '220$-13000$',
      'catagory'=>'',
      'description' => 'Gambella National Park is located in the Gambella Region of southwestern Ethiopia, about 770
        kilometers from Addis Ababa.
        <span class="hidden">
          It has a tropical monsoon climate with high temperatures and heavy rainfall during the wet season. The park'.'s diverse landscape includes grasslands, wetlands, and riverine forests at altitudes ranging from 400 to 700 meters.
        </span>
      ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'AWASH NATIONAL PARK',
      'Price' => '200$-13000$',
      'catagory'=>'',
      'description' => 'This national park is located at the border of Oromia state and Afar state, covering an area of 827 square
        kilometers.
        <span class="hidden">
          It lies at an altitude of 2007 meters above sea level. This park is 225 km east of Addis Ababa, and a few kilometers west of Awash and east of Meteher. The park is best known for its diverse landscapes and rural settings.
        </span>
      ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'ABIJATTA-SHALLA',
      'Price' => '240$-14000$',
      'catagory'=>'',
      'description' => 'This national park is located in the Oromia Region, 200 km south of Addis Ababa, and east of the Batu-Shashamane highway. 
          <span class="hidden">
            The altitude of the park ranges from 1540 to 2075 meters. The park is home to 300 species of birds that are listed as endemics, residents, and migratory.
          </span>
      ',
  ]
];






// foreach ($locations as $location) {
//   $imagelocation = $location['image'];
//   $imageData = addslashes(file_get_contents($imagelocation));

//   $title = $location['title'];
//   $description = $location['description'];

  
//   $checkQuery = "SELECT COUNT(*) AS count FROM locations WHERE title = '$title'";
//   $result = mysqli_query($con, $checkQuery);
//   $row = mysqli_fetch_assoc($result);

//   if ($row['count'] == 0) {
 
//     $sql = "INSERT INTO locations (title, description, loc_img) VALUES ('$title', '$description', '$imageData')";
    
//     mysqli_query($con, $sql);
//   }
// }

// $_POST['historical'];
// $_POST['natural'];
// $_POST['national'];