<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashbord</title>
  <link rel="stylesheet" href="../CSS/dashboard.css">
  <link rel="stylesheet" href="../CSS/index.css">
</head>

<body>
  <section class="dashboard-container">
    <div class="aside">
      <div class="side-list">
        <div class="logo">
          <i class="fas fa-map-marker-alt"></i>
          <span>Tourist</span>
        </div>
        <ul>

          <li><a href="dashboard.php">Dashboard</a></li>
          <li><a href="manageBooking.php">Bookings</a></li>
          <li><a href="newUser.php">New User</a></li>
          <li><a href="updateTourismSite.php">Update Tourist sites</a></li>
          <li><a href="updateServicePackages.php">Update Tour Service Package</a></li>
          <li><a href="#"></a></li>
          <li><a href="../index.html/index.php">Back To home</a></li>
          <li><a href="#">Logout</a></li>
        </ul>
      </div>
    </div>
    </div>

    <div class="main-dashboard">


      <div class="Welcome-to-dashboard">
        <h1>Welcome to Admin Dashboard</h1>
        <div class="profile">
          <form action="searchUser.php">

            <input type="text" placeholder="Search user">
            <input type="submit" value="Search">
            <div class="username">




          </form>

          <?php
if(isset($_SESSION['username']))
          $_SESSION['username']
        ?>
        </div>
        <div class="help">
          <a href="">Help</a>
        </div>
      </div>
    </div>

    <div class="dataContainer">

      <script src="../js/searchUser.js"></script>