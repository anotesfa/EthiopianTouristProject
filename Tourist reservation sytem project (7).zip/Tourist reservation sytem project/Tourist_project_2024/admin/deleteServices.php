<?php
include '../../databases for tourist reservation sytem/dbconnection.php'; 


    $loc_id = $_POST['serv_id'];

    $sql = "DELETE FROM services WHERE serv_id='$serv_id'";

    if (mysqli_query($con, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($con);
    }

    mysqli_close($con);
    header("Location: dashboard.php"); 
  