<?php
include '../../databases for tourist reservation sytem/dbconnection.php'; 


    $loc_id = $_POST['loc_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price =$_POST['price'];

    if (!empty($_FILES['loc_img']['name'])) {
        $imgData = addslashes(file_get_contents($_FILES['loc_img']['tmp_name']));
        $sql = "UPDATE locations SET title='$title', description='$description', loc_img='$imgData',
        Price = $price;
        
         WHERE loc_id='$loc_id'";
    } else {
        $sql = "UPDATE locations SET title='$title', description='$description' WHERE loc_id='$loc_id'";
    }

    if (mysqli_query($con, $sql)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }

    header("Location: dashboard.php"); 