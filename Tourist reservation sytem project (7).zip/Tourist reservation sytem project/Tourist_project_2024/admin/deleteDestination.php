<?php
include '../../databases for tourist reservation sytem/dbconnection.php'; 


    $loc_id = $_POST['loc_id'];

    $sql = "DELETE FROM locations WHERE loc_id='$loc_id'";

    if (mysqli_query($con, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($con);
    }

    mysqli_close($con);
    header("Location: dashboard.php"); 
  