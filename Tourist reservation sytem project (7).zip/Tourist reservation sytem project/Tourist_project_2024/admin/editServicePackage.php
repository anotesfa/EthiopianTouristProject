<?php
include '../../databases for tourist reservation sytem/dbconnection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serv_id = $_POST['serv_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    if (!empty($_FILES['serv_img']['name'])) {
        $imgData = addslashes(file_get_contents($_FILES['serv_img']['tmp_name']));
        $sql = "UPDATE services SET serv_name='$title', description='$description', serv_img='$imgData' WHERE serv_id='$serv_id'";
    } else {
        $sql = "UPDATE services SET serv_name='$title', description='$description' WHERE serv_id='$serv_id'";
    }

    if (mysqli_query($con, $sql)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }

    header("Location: dashboard.php");
    exit();
}