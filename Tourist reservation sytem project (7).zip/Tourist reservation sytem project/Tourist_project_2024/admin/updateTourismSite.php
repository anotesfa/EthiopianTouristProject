<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Users</title>
  <link rel="stylesheet" href="../CSS/admin.css">
  <link rel="stylesheet" href="../CSS/toursitSite.css">

</head>

<body>
  <?php
  include 'updateDistination.php';
  include 'dashboardcommon.php';

  echo '<table class="table-admin" border="1">';
  echo "<tr>
    <td class='bold'>Location ID</td>
    <td class='bold'>Name</td>
    <td class='bold'>Description</td>
    <td class='bold'>Images</td>
    <td class='bold'>Edit</td>
    <td class='bold'>Delete</td>
  </tr>";

  $sql = 'SELECT * FROM locations';
  $result = mysqli_query($con, $sql);
  while ($data = mysqli_fetch_array($result)) {
    // Escape the title and description for safe use in JavaScript
    $escapedTitle = addslashes($data['title']);
    $escapedDescription = addslashes($data['description']);
    echo "<tr>
      <td class='data'>{$data['loc_id']}</td>
      <td class='data'>{$data['title']}</td>
      <td class='data'>{$data['description']}</td>
      <td><img width='100px' height='100px' src='data:image/jpeg;base64," . base64_encode($data['loc_img']) . "'></td>
      <td class='bold'><a href='#' onclick='openEditModal({$data['loc_id']}, \"{$escapedTitle}\", \"{$escapedDescription}\")'>Edit</a></td>
      <td class='bold'><a href='#' onclick='openDeleteModal({$data['loc_id']})'>Delete</a></td>
    </tr>";
  }
  echo '</table>';
  ?>

  <!-- Edit Modal -->
  <div id="editModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeModal('editModal')">&times;</span>
      <h2>Edit Destination</h2>
      <form action="editDestination.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" id="editLocId" name="loc_id">
        <label for="title">Title:</label>
        <input type="text" id="editTitle" name="title" required><br><br>
        <label for="title">Price:</label>
        <input type="text" id="editTitle" name="price" required><br><br>
        <label for="description">Description:</label>
        <textarea id="editDescription" name="description" required></textarea><br><br>
        <label for="loc_img">Image:</label>
        <input type="file" name="loc_img"><br><br>
        <button type="submit">Update</button>
      </form>
    </div>
  </div>

  <!-- Delete Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeModal('deleteModal')">&times;</span>
      <h2>Delete Destination</h2>
      <p>Are you sure you want to delete this destination?</p>
      <form action="deleteDestination.php" method="POST">
        <input type="hidden" id="deleteLocId" name="loc_id">
        <button type="submit">Yes, Delete</button>
        <button type="button" onclick="closeModal('deleteModal')">Cancel</button>
      </form>
    </div>
  </div>

  <script>
  function openEditModal(loc_id, title, description) {
    document.getElementById('editLocId').value = loc_id;
    document.getElementById('editTitle').value = title;
    document.getElementById('editDescription').value = description;
    document.getElementById('editModal').style.display = 'block';

  }

  function openDeleteModal(loc_id) {
    document.getElementById('deleteLocId').value = loc_id;
    document.getElementById('deleteModal').style.display = 'block';

  }

  function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
  }
  </script>

</body>

</html>