<?php
include '../../databases for tourist reservation sytem/dbconnection.php';
include 'dashboardcommon.php';



$sql = "select * form users where T_id= $_POST['id']";