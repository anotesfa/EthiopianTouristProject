<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Users</title>
</head>

<body>
  <?php
include '../../databases for tourist reservation sytem/dbconnection.php';
include 'dashbordcommon.php';?>


</body>

</html>