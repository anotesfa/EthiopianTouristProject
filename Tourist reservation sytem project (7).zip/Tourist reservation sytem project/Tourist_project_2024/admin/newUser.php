<!DOCTYPE html>
<html lang="en">


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Users</title>
</head>

<body>
  <?php
include '../../databases for tourist reservation sytem/dbconnection.php';
include 'dashboardcommon.php';?>



  <h1 class="heading">New Tourists

  </h1>
  <?php
  
  echo'<table class="table-admin" border="1">';
  echo "<tr>
  <td class='bold'>Toursit ID</td>
  <td class='bold'>Username</td>
  <td class='bold'>Email</td>
  <td class='bold'>Password</td>
  <td class='bold'>Profile picture</td>
  <td class='bold'>Booking</td>
  </tr>
  
  ";
  $sql = 'SELECT * FROM users';
  $result = mysqli_query ($con,$sql);
  while($data =mysqli_fetch_array($result)){
echo "<tr>
<td  class='data'>$data[user_id]</td>
<td  class='data'> $data[col_username]</td>'
<td  class='data'> $data[col_email]</td>
<td  class='data'>$data[col_password]</td>
 <td><img width='100px' height='100px'src='data:image/jpeg;base64,".base64_encode($data['col_img_data'])."'></td>'
</tr>







";

  }
  
  echo "</table>";
  
  
  
  ?>

  </div>






  </div>

  </section>
</body>

</html>