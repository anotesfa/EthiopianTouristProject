<?php
include '../../databases for tourist reservation sytem/dbconnection.php';

$services = [
  [
    'image' => '../../images/images/jifar.jpeg',
    'title' => 'WorldWide Tours',
    'catagory'=>'',
    'description' => '<div class="content">
    <h1>ABBA JIFAR PALACE</h1>
    <p>This is a web based tourism system developed by 3rd year software students at jimma university</p>
  </div>',
],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'Hotel Reservations',
      'catagory'=>'',
      'description' => 'This is a web based tourism system developed by 3rd year software students at jimma university',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'Travel Guides',
      'catagory'=>'',
      'description' => 'This is a web based tourism system developed by 3rd year software students at jimma university',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'Event management',
      'catagory'=>'',
      'description' => ' This is a web based tourism system developed by 3rd year software students at jimma university',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'Package Deals',
      'catagory'=>'',
      'description' => 'Offers bundled travel packages, including accommodation, transport, and activities at discounted rates.',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'Payment Processing ',
      'catagory'=>'',
      'description' => 'Integrates secure online payment gateways for hassle-free transactions.
        ',
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'Multilingual & Multi-currency Support',
      'catagory'=>'',
      'description' => 'Provides a user-friendly experience by supporting different languages and currencies.',
  ],
 
];






// foreach ($services as $service) {
//   $imagelocation = $service['image'];
//   $imageData = addslashes(file_get_contents($imagelocation));

//   $title = $service['title'];
//   $description = $service['description'];

  
//   $checkQuery = "SELECT COUNT(*) AS count FROM locations WHERE title = '$title'";
//   $result = mysqli_query($con, $checkQuery);
//   $row = mysqli_fetch_assoc($result);

//   if ($row['count'] == 0) {
 
//     $sql = "INSERT INTO services (serv_name, description, serv_img) VALUES ('$title', '$description', '$imageData')";
    
//     mysqli_query($con, $sql);
//   }
// }