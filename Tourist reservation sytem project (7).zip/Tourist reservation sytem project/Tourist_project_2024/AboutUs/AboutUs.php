<?php

include '../common/header.php';
include '../../databases for tourist reservation sytem/dbconnection.php';

// Fetch team data from the database
$sql = 'SELECT * FROM gallary';
$result = mysqli_query($con, $sql);

$team = []; 

while ($data = mysqli_fetch_assoc($result)) {
    $team[] = $data; // Store each row in the array
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ethiopian Tourism</title>
  <link rel="stylesheet" href="../CSS/AboutUs.css">
  <link rel="stylesheet" href="../CSS/index.css">
</head>

<body>
  <section class="header">
    <p>About Us</p>
  </section>

  <section class="about-section">
    <div class="image-container">
      <img src="men.png" alt="About Us">
    </div>
    <div class="about-content-container">
      <h1>Welcome to <span style="color: #7cb342;">Tourist</span></h1>
      <p>
        We are dedicated to providing exceptional services to make your travel experience unforgettable.
        Our commitment to excellence extends to every aspect of your journey. From first-class flights and handpicked
        accommodations to personalized city tours, we create experiences that blend comfort, convenience, and adventure.
      </p>
      <p>
        Let us guide you to the best destinations, where stunning landscapes, cultural treasures, and world-class
        hospitality await. Your dream vacation starts here with us.
      </p>
      <div class="features">
        <ul>
          <li>First Class Flights</li>
          <li>5 Star Accommodations</li>
          <li>150 Premium City Tours</li>
        </ul>
        <ul>
          <li>Handpicked Hotels</li>
          <li>Latest Model Vehicles</li>
          <li>24/7 Service</li>
        </ul>
      </div>
      <button class="read-more">Read More</button>
    </div>
  </section>

  <section class="section">
    <p>TOUR GUIDE</p>
    <h1>Meet Our Guide</h1>

    <div class="team-container">
      <?php
      if (!empty($team)) {
          foreach ($team as $member) { ?>
      <div class="team-member">
        <img src="data:image/jpeg;base64,<?php echo base64_encode($member['image']); ?>" alt="Team Member">


        <div class="social-icons">
          <i class="fab fa-facebook"></i>
          <i class="fab fa-twitter"></i>
          <i class="fab fa-instagram"></i>
        </div>
        <h3><?php echo htmlspecialchars($member['name']); ?></h3>
        <p><?php echo htmlspecialchars($member['catagory']); ?></p>

      </div>
      <?php 
          }
      } else {
          echo "<p>No team members found.</p>";
      }
      ?>
    </div>
  </section>

  <?php include '../common/footer.php'; ?>

</body>

</html>