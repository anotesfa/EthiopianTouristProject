document.addEventListener("DOMContentLoaded", function () {
  const bookNowBtn = document.querySelector(".button-submit");
  const popup = document.querySelector(".popup");
  const popupOverlay = document.querySelector(".popup-overlay");
  const closePopupBtn = document.getElementById("close-popup");
  const confirmBookingBtn = document.getElementById("confirm-booking");

  const fullName = document.getElementById("name");
  const email = document.getElementById("email");
  const dateInput = document.getElementById("datetime");
  const destinationSelect = document.getElementById("destination");
  const tourSelect = document.getElementById("tour-options");
  const paymentSelect = document.getElementById("payment-options");
  const amountInput = document.getElementById("amount");

  
  function validateName() {
    const name = fullName.value;
    const nameError = document.getElementById("name-error");
    if (name.length < 3) {
      nameError.textContent = "Name must be at least 3 characters long";
      return false;
    } else {
      nameError.textContent = "";
      return true;
    }
  }

  function validateEmail() {
    const emailValue = email.value;
    const emailError = document.getElementById("email-error");
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(emailValue)) {
      emailError.textContent = "Please enter a valid email address";
      return false;
    } else {
      emailError.textContent = "";
      return true;
    }
  }

  function validateDestination() {
    const destination = destinationSelect.value;
    const destinationError = document.getElementById("destination-error");
    if (destination === "") {
      destinationError.textContent = "Please select a destination";
      return false;
    } else {
      destinationError.textContent = "";
      return true;
    }
  }

  function updateAmount() {
    const tourPackage = tourSelect.value;
    amountInput.value = tourPackage;
  }

  function showPopup() {
    popup.classList.add("show");
    popupOverlay.classList.add("show");
  }


  function closePopup() {
    popup.classList.remove("show");
    popupOverlay.classList.remove("show");
  }


  fullName.addEventListener("keyup", validateName);
  email.addEventListener("keyup", validateEmail);
  destinationSelect.addEventListener("change", validateDestination);

 
  document
    .getElementById("booking-form")
    .addEventListener("submit", function (event) {
      if (!validateName() || !validateEmail() || !validateDestination()) {
        event.preventDefault(); 
        alert("Please fill out all required fields correctly.");
      } else {
        
        event.preventDefault(); 
        showPopup();
      }
    });

 
  closePopupBtn.addEventListener("click", closePopup);

  confirmBookingBtn.addEventListener("click", function () {

    document.getElementById("booking-form").submit(); 
  });
});
