function SearchUser() {
  user_id = prompt("Enter the name or the id of the User ");

  if (user_id ===""){

  }
  else if(user_id=){

  }
}
