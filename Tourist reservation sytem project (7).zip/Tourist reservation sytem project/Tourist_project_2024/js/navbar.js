const menu = document.getElementById("toggle-menu");
const navBar = document.getElementsByClassName("nav-bar");

menu.addEventListener("click", () => {
  navBar.classList.toggle("appear");
});
