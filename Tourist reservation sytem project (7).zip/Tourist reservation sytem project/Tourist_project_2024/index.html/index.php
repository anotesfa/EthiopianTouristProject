<?php

include '../common/header.php';
?>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to Tourist Reseravation system</title>
  <link rel="stylesheet" href="../CSS/services.css">
  <link rel="stylesheet" href="../CSS/index.css" />
  <link rel="stylesheet" href="../CSS/AboutUs.css" />


</head>

<body>

  <div class="home-content">
    <h1>Enjoy Your Vacation With Us</h1>
    <p>
      Explore Ethiopia your way! Plan, book, and experience the rich
      culture, breathtaking landscapes, and unforgettable adventures of
      Ethiopia with ease. Start your journey today!
    </p>
    <div class="search">
      <input type="button" class='button' value="Book Now" />

    </div>
  </div>
  </section>

  <?php
  include '../common/service_boxs.php';
  ?>

  <section></section>
  <section></section>
  <section></section>
  <section></section>

  <?php 

include '../common/footer.php';
?>