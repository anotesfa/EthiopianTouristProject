const userName = document.querySelector("#name");
const email = document.querySelector("#email");
const creatPassword = document.querySelector("#crpass");
const conformPassword = document.querySelector("#confirmpass");
const formButton = document.querySelector("#register");
const form = document.querySelector("form"); // Select the form element
let timeOut;

formButton.addEventListener("click", (e) => {
  e.preventDefault(); // Prevent the form from submitting automatically
  clearTimeout(timeOut);
  checkInputs(); // Validate inputs
});

function validateEmail(email) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}

function checkInputs() {
  const userNameValue = userName.value.trim();
  const emailValue = email.value.trim();
  const password1 = creatPassword.value.trim();
  const password2 = conformPassword.value.trim();

  let isValid = true;

  // Validate Username
  if (userNameValue === "") {
    showError("#error1", "#invalid1", "User Name cannot be blank!");
    isValid = false;
  } else {
    showSuccess("#valid1", "#error1", "#invalid1");
  }

  // Validate Email
  if (emailValue === "") {
    showError("#error2", "#invalid2", "Email cannot be blank!");
    isValid = false;
  } else if (!validateEmail(emailValue)) {
    showError("#error2", "#invalid2", "Please enter a valid email address!");
    isValid = false;
  } else {
    showSuccess("#valid2", "#error2", "#invalid2");
  }

  // Validate Password
  if (password1 === "") {
    showError("#error3", "#invalid3", "Password cannot be blank!");
    isValid = false;
  } else {
    showSuccess("#valid3", "#error3", "#invalid3");
  }

  // Confirm Password
  if (password2 === "") {
    showError("#error4", "#invalid4", "Please confirm your password!");
    isValid = false;
  } else if (password1 !== password2) {
    showError("#error4", "#invalid4", "Passwords do not match!");
    isValid = false;
  } else {
    showSuccess("#valid4", "#error4", "#invalid4");
  }

  if (isValid) {
    form.submit();
  }
}

function showError(errorSelector, invalidSelector, message) {
  const errorElement = document.querySelector(errorSelector);
  const invalidElement = document.querySelector(invalidSelector);

  errorElement.classList.add("error-opacity");
  invalidElement.classList.add("errorel-opacity");
  errorElement.innerText = message;
}

function showSuccess(validSelector, errorSelector, invalidSelector) {
  const validElement = document.querySelector(validSelector);
  const errorElement = document.querySelector(errorSelector);
  const invalidElement = document.querySelector(invalidSelector);

  validElement.classList.add("success-opacity");
  errorElement.classList.remove("error-opacity");
  invalidElement.classList.remove("errorel-opacity");
}
