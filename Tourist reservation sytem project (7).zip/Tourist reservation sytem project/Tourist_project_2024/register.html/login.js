const userName = document.querySelector("#name");
const password = document.querySelector("#crpass");
const form = document.querySelector("form");
const formButton = document.querySelector("#login");

formButton.addEventListener("click", (e) => {
  if (checkInputs()) {
    form.submit(); // Submit the form if validation passes
  } else {
    e.preventDefault(); // Prevent form submission if validation fails
  }
});

function checkInputs() {
  let isValid = true;

  // Validate username
  const userNameValue = userName.value.trim();
  const userNameErrorElement = document.querySelector("#error1");
  const userNameInvalidElement = document.querySelector("#invalid1");
  const userNameValidElement = document.querySelector("#valid1");

  if (userNameValue === "") {
    userNameErrorElement.innerText = "User Name cannot be blank!";
    userNameErrorElement.classList.add("error-opacity");
    userNameInvalidElement.classList.add("errorel-opacity");
    isValid = false;
  } else if (userNameValue.length < 3) {
    userNameErrorElement.innerText = "User Name must be at least 3 characters!";
    isValid = false;
  } else if (userNameValue.length >= 30) {
    userNameErrorElement.innerText = "User Name cannot exceed 30 characters!";
    isValid = false;
  } else if (!/^[a-zA-Z-]+$/.test(userNameValue)) {
    userNameErrorElement.innerText = "Only letters are allowed!";
    isValid = false;
  } else {
    userNameErrorElement.classList.remove("error-opacity");
    userNameInvalidElement.classList.remove("errorel-opacity");
    userNameValidElement.classList.add("success-opacity");
  }

  // Validate password
  const passwordValue = password.value.trim();
  const passwordErrorElement = document.querySelector("#error3");
  const passwordInvalidElement = document.querySelector("#invalid3");
  const passwordValidElement = document.querySelector("#valid3");

  if (passwordValue === "") {
    passwordErrorElement.innerText = "Password cannot be blank!";
    passwordErrorElement.classList.add("error-opacity");
    passwordInvalidElement.classList.add("errorel-opacity");
    isValid = false;
  } else {
    passwordErrorElement.classList.remove("error-opacity");
    passwordInvalidElement.classList.remove("errorel-opacity");
    passwordValidElement.classList.add("success-opacity");
  }

  return isValid;
}
