<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Welcome To Tourist Reservation - Register</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="../css/signup.css" />
</head>

<body>
  <div class="signup-container">

    <header>
      <h1><i class="fas fa-map-marker-alt"></i> Registration Form</h1>
    </header>
    <form action="../../databases for tourist reservation sytem/signupdb.php" method="POST" name="signup"
      enctype="multipart/form-data">

      <div class="input">
        <!-- Username -->
        <label class="input-label">

          <input type="text" placeholder="Enter your Username" id="name" name="username" required />
          <i class="fas fa-check-circle success" id="valid1"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid1"></i>
          <div class="error" id="error1">Error message</div>
        </label>

        <!-- Email -->
        <label class="input-label">

          <input type="email" placeholder="Enter your Email" id="email" name="email" required />
          <i class="fas fa-check-circle success" id="valid2"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid2"></i>
          <div class="error" id="error2">Error message</div>
        </label>

        <!-- nationality -->
        <label class="input-label">

          <select id="nationality" name="nationality" required>
            <option value="" disabled selected>Select your nationality</option>
            <option value="Ethiopian">Ethiopian 🇪🇹</option>
            <option value="American">American &#127482;&#127480;</option>
            <option value="Indian">Indian &#127470;&#127475;</option>
            <option value="Chinese">Chinese &#127464;&#127475;</option>
            <option value="British">British &#127468;&#127463;</option>
            <option value="German">German &#127465;&#127466;</option>
            <option value="French">French &#127467;&#127479;</option>
            <option value="Canadian">Canadian &#127464;&#127462;</option>
            <option value="Australian">Australian &#127462;&#127482;</option>
          </select>
          <i class="fas fa-check-circle success" id="valid1"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid1"></i>

        </label>


        <!-- gender -->

        <label class="input-radio"> <span>Gender</span>

          <input type="radio" id="male" name="gender" value="Male"> Male
          <input type="radio" id="male" name="gender" value="Female"> Female

        </label>



        <!-- Password -->
        <label class="input-label">

          <input type="password" placeholder="Create Password" id="crpass" name="password" required />
          <i class="fas fa-check-circle success" id="valid3"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid3"></i>
          <div class="error" id="error3">Error message</div>
        </label>

        <!-- Confirm Password -->
        <label class="input-label">
          <input type="password" placeholder="Confirm Password" id="confirmpass" name="confirm_password" required />
          <i class="fas fa-check-circle success" id="valid4"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid4"></i>
          <div class="error" id="error4">Error message</div>
        </label>
      </div>


      <label class="input-label">

        <input type="file" placeholder="choose profile pic" id="profilePic" name="profilePic" required />

      </label>

      <!-- Terms and Conditions -->
      <div class="accept">
        <label>
          <input type="checkbox" class="checkbox" required /> I accept all
          terms & conditions
        </label>
      </div>

      <!-- Footer -->
      <div class="footer-container">
        <input type="submit" class="button" id="register" value="Register Now">

        <p>Already have an account? <a href="login.php">Login now</a></p>

      </div>
    </form>
  </div>
  </div>
  <script defer src="signup.js"></script>
</body>

</html>