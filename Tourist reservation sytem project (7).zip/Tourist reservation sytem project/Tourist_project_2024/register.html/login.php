<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Welcome To Tourist Reservation - Register</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="../css/signup.css" />
</head>

<body>
  <div class="signup-container">

    <header>
      <h1><i class="fas fa-map-marker-alt"></i> Login to Tourist</h1>
    </header>
    <form action="../../databases for tourist reservation sytem/logindb.php" method="post" name="loginform"
      enctype="multipart/form-data">

      <div class="input">
        <!-- Username -->
        <label class="input-label">
          <i class="fa fa-user-circle relative" aria-hidden="true"></i>
          <input type="text" placeholder="Enter your Username" id="name" name="username" required
            onkeyup="validateUsername()" />
          <i class="fas fa-check-circle success" id="valid1"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid1"></i>
          <div class="error" id="error1">Error message</div>
        </label>



        <!-- Password -->
        <label class="input-label">
          <i class="fa fa-key relative" aria-hidden="true"></i>
          <input type="password" placeholder=" Password" id="crpass" name="password" required />
          <i class="fas fa-check-circle success" id="valid3"></i>
          <i class="fas fa-exclamation-circle errorel" id="invalid3"></i>
          <div class="error" id="error3">Error message</div>
        </label>

      </div>

      <div class="forgot_pass">
        <a href="#" class="links">forgot Password</a>
      </div>




      <!-- Terms and Conditions -->
      <div class="accept">
        <label>
          <input type="checkbox" class="checkbox" required /> I accept all
          terms & conditions
        </label>
      </div>

      <!-- Footer -->
      <div class="footer-container">
        <input type="submit" class="button" id="login" value="Login now">

        <p>Don't have an account? <a href="signup.php" class="links">Sign up</a></p>

      </div>
    </form>
  </div>
  </div>
  <script src="login.js"></script>
</body>

</html>