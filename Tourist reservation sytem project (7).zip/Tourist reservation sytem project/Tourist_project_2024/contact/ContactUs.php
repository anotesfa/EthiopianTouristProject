<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="../CSS/contact1.css" />
  <link rel="stylesheet" href="../CSS/index.css" />
  <link rel="stylesheet" href="../CSS/AboutUs.css" />
</head>


</head>

<body>
  <section>
    <?php

include '../common/header.php';
?>
    <h2 class="contact-us-top"><strong>CONTACT US</strong></h2>


  </section>

  <section class="contact">
    <div class="contact--header">
      <h2><strong>CONTACT US</strong></h2>
      <h1><strong>Contact For Any Query</strong></h1>
    </div>
    <div class="contact-element">
      <div class="get-in-touch">
        <h3>Contact Us</h3>
        <p>You can reach us at any time using the contact information provided below. We are available to assist
          you with your inquiries.</p>

        <div class="contact-info">
          <div class="contact-item">
            <div><i class='bx bxs-location-plus'></i></div>
            <div>
              <p><strong class="new">Office</strong><br>KITO-FURDISA JIT, Jimma, ETHIOPIA </p>
            </div>
          </div>
          <div class="contact-item">
            <div><i class='bx bxs-phone'></i></div>
            <div>
              <p><strong class="new">Mobile</strong><br> +251911223344</p>
            </div>
          </div>
          <div class="contact-item">
            <div><i class='bx bx-envelope'></i></div>
            <div>
              <p><strong class="new">Email</strong><br>ethioturism5@gmail.com</p>
            </div>
          </div>
        </div>
      </div>

      <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d61269.
            07415004087!2d36.81228371916082!3d7.667443200359001!2m3!1f0!2f0!3f0!3m2!1i1024
            !2i768!4f13.1!3m3!1m2!1s0x17adb882f6e6a723%3A0xf45a83bb90208fd8!2sJimma!5e0!3m2!
            1sen!2set!4v1732568023831!5m2!1sen!2set" width="600" height="450" style="border:0;" allowfullscreen=""
          loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
      <div class="contact-form">
        <form action="../../databases for tourist reservation sytem/feedbackdb.php">
          <input type="text" placeholder="Your Full Name" name="fullName"><br>
          <input type="email" placeholder="Your Email" name="email"><br>
          <textarea placeholder="Subject" name="subject"></textarea><br>
          <textarea placeholder="Your feedback..." name="feedback"></textarea><br>
          <input type="submit" value="Send feedback">
        </form>
      </div>
    </div>
  </section>



</body>

</html>