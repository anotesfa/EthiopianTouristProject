<?php
include '../../databases for tourist reservation sytem/dbconnection.php';
// include '../../databases for tourist reservation sytem/locationFilter.php';

$sql = "SELECT title,Price, description,Price,loc_img FROM locations";
$result = mysqli_query($con,$sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DESTINATION</title>
  <link rel="stylesheet" href="../CSS/destination.css">
  <link rel="stylesheet" href="../CSS/index.css">
  <link rel="stylesheet" href="../CSS/AboutUs.css">
</head>

<body>
  <section>



    <?php
    include '../common/header.php';

    include '../admin/updateDistination.php';
   
    ?>

    <h1 class="header desthination-header">DESTINATION</h1>
  </section>
  <form action="../../databases for tourist reservation sytem/locationFilter.php" method="POST">
    <label for="category" class="label">Select Category:</label>
    <select name="category" class="category" id="category">
      <option value="historical">Historical Heritage Sites</option>
      <option value="natural">Natural Resources</option>
      <option value="national">National Parks</option>
    </select>
    <button type="submit" class="button">Filter</button>
  </form>
  <div class="locations">

    <?php
    if(isset($filterresult)){
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
           
            $imageData = base64_encode($row['loc_img']);
            $imageSrc = 'data:image/jpeg;base64,' . $imageData;

            echo '
            <div class="box">
                <img src="' . $imageSrc . '" alt="' . $row['title'] . '">
                <div class="content">
                    <h1>' . $row['title'] . '</h1>
                     <p> ' . $row['Price'] . '</p>
                    <p>' . $row['description'] . '</p>
                    <button class="button read-more">Read more</button>
                    <a href="../booking/booking.php" class="button">Make your choice</a>
                </div>
            </div>';
        }
    } else {
        echo '<p>No destinations available.</p>';
    }
    }else{
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            
            $imageData = base64_encode($row['loc_img']);
            $imageSrc = 'data:image/jpeg;base64,' . $imageData;

            echo '
            <div class="box">
                <img src="' . $imageSrc . '" alt="' . $row['title'] . '">
                <div class="content">
                    <h1>' . $row['title'] . '</h1>
                    <p> ' . $row['Price'] . '</p>
                    <p>' . $row['description'] . '</p>
                    <button class="button read-more">Read more</button>
                    <a href="" class="button">Make your choice</a>
                </div>
            </div>';
        }
    } else {
        echo '<p>No destinations available.</p>';
    }






    }
    
  
    ?>
  </div>

  <script src="destination.js"></script>

  <?php 
  include '../common/footer.php';
  ?>
</body>

</html>