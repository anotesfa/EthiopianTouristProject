const descriptions = document.getElementsByClassName("hidden");
const readMoreButtons = document.getElementsByClassName("read-more");

Array.from(readMoreButtons).forEach((button, index) => {
  button.addEventListener("click", () => {
    const description = descriptions[index];

    if (description.classList.contains("show")) {
      description.classList.remove("show");
      button.innerText = "Read More";
    } else {
      description.classList.add("show");
      button.innerText = "Less";
    }
  });
});
