<?php
include '../../databases for tourist reservation sytem/dbconnection.php';



$sql = "SELECT serv_name, description, serv_img FROM services";
$result = mysqli_query($con, $sql);

if (!$result) {
    die("Database query failed: " . mysqli_error($con));
}
?>

<body>
  <div class="our-services">
    <div class="serv">
      <h1>Our Services</h1>
    </div>
  </div>

  <section>
    <div class="all">
      <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $imageData = base64_encode($row['serv_img']);
                    $imageSrc = 'data:image/jpeg;base64,' . $imageData;
                    echo '
                    <div class="box-services">
                        <img src="' . $imageSrc . '" alt="' . htmlspecialchars($row['serv_name']) . '">
                        <h1>' . htmlspecialchars($row['serv_name']) . '</h1>
                        <p>' . htmlspecialchars($row['description']) . '</p>
                    </div>';
                }
            } else {
                echo '<p>No services available.</p>';
            }
            ?>
  </section>
</body>