<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: ../register.html/login.php');
    exit(); // Ensure script stops execution after redirection
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tourist Reservation System</title>
  <link rel="stylesheet" href="../CSS/index.css" />
  <link rel="stylesheet" href="../CSS/AboutUs.css" />
  <link rel="stylesheet" href="../CSS/ContactUs.css" />
  <link rel="stylesheet" href="../CSS/services.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css"
    integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

  <section class="top">
    <div class="top--right">
      <div>
        <i class="fas fa-map-marker-alt"></i>
        <span>Jimma, Oromia, Ethiopia</span>
      </div>
      <div>
        <i class="fa fa-phone" aria-hidden="true"></i>
        <span>+251953290941</span>
      </div>
      <div>
        <i class="fa fa-envelope" aria-hidden="true"></i>
        <span>tourist@gmail.com</span>
      </div>
    </div>
    <!-- Left side -->
    <div class="top--left">
      <a href="#"><i class="fab fa-facebook"></i></a>
      <a href="#"><i class="fab fa-twitter"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
      <a href="#"><i class="fab fa-youtube"></i></a>
    </div>
  </section>

  <section class="section-home">
    <div class="logo-nav-hero">
      <div class="logo">
        <i class="fas fa-map-marker-alt"></i>
        <span>Tourist</span>
      </div>

      <div class="nav-bar">
        <ul class="main-menu">
          <li class="main-nav">
            <a href="../index.html/index.php" target="_self">Home</a>
            <a href="../AboutUs/AboutUs.php" target="_self">About</a>
            <a href="../service/services.php" target="_self">Tour Services</a>
            <div class="dropdown">
              <label for="pages" class="dropdown-label">Pages</label>
              <ul id="pages" class="dropdown-menu">
                <li>
                  <a href="../Distination.html/destination.php" target="_self">Destinations</a>
                </li>
                <li>
                  <a href="../booking/booking.php" target="_self">Book Now</a>
                </li>
              </ul>
            </div>
            <a href="../contact/ContactUs.php" target="_self">Contact Us</a>
          </li>

        </ul>
        <div class="info-container">
          <span class="user">
            <span class="tourist-profile"><?php echo htmlspecialchars($_SESSION['username']); ?></span>

            <?php if (isset($_SESSION['profile_pic'])) { ?>
            <img width="100px" height="100px" src="<?php echo htmlspecialchars($_SESSION['profile_pic']); ?>"
              alt="Profile Picture" class="profile-pic">
            <?php } ?>
          </span>
          <?php if (!isset($_SESSION['username'])) { ?>
          <button class="register login">
            <a href="../register.html/login.php">Login Now</a>
          </button>
          <?php } else { ?>
          <button class="register">
            <a href="../register.html/logout.php">Logout</a>
          </button>


          <?php if ($_SESSION['role'] === 'admin') { ?>
          <button class="register">
            <a href="../admin/dashboard.php" class="register button">Dashboard</a>
          </button>
          <?php } ?>
          <?php } ?>
        </div>
      </div>

      <div class="toggle-menu" id="toggle-menu">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>






    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
      const toggleMenu = document.getElementById("toggle-menu");
      const navBar = document.querySelector(".nav-bar");

      toggleMenu.addEventListener("click", function() {
        navBar.classList.toggle("active");
      });
    });
    </script>