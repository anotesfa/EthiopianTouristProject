<?php 
include '../common/header.php'; 
// include 'bookingdb.php';
include '../../databases for tourist reservation sytem/dbconnection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Booking</title>
  <link rel="stylesheet" href="../CSS/booking.css" />
  <link rel="stylesheet" href="../CSS/AboutUs.css">
  <link rel="stylesheet" href="../CSS/index.css">
</head>

<body>
  <div class="booking">
    <h1>Book Now</h1>
  </div>

  <?php
  if (isset($_SESSION['role']) && $_SESSION['role'] !== 'admin') {
    if (isset($_SESSION['booking'])) {
      echo ' <section class="all mybookings">
      <div class="mybooking">
        <h1 class="h1">My Booking</h1>
      </div>
      <table border="1">
        <tr>
          <th>Ticket Number</th>
          <th>Full Name</th>
          <th>Email</th>
          <th>Booking Date</th>
          <th>Destination</th>
          <th>Amount</th>
          <th>Tour Package</th>
          <th>Special Request</th>
        </tr>';

      $username = mysqli_real_escape_string($con, $_SESSION['username']);
      $sql = "SELECT * FROM booking WHERE Full_name = '$username'";
      $result = mysqli_query($con, $sql);

      while ($row = mysqli_fetch_array($result)) {
        echo "
          <tr>
            <td>{$row['Ticket_no']}</td>
            <td>{$row['Full_name']}</td>
            <td>{$row['Email']}</td>
            <td>{$row['Date']}</td>
            <td>{$row['Destination']}</td>
            <td>{$row['Amount']}</td>
            <td>{$row['Payment']}</td>
            <td>{$row['special_request']}</td>
          </tr>
        ";
      }
      echo "</table></section>";
    }
  }  ?>

  <section>
    <div class="topic">
      <h1 class="h1">3 Easy Steps</h1>
    </div>
    <section class="all">
      <div class="for-all divs">
        <div class="circle">
          <i class="fas fa-globe"></i>
        </div>
        <h3 class="sub-topic">Choose Your Destination</h3>
        <p>Select your preferred destination for an amazing experience.</p>
      </div>
      <div class="for-all divs">
        <div class="circle">
          <i class="fas fa-plane"></i>
        </div>
        <h3 class="sub-topic">Fly Today</h3>
        <p>After confirming your destination, get ready to fly!</p>
      </div>
      <div class="for-all divs">
        <div class="circle">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <h3 class="sub-topic">Pay Online</h3>
        <p>Complete your booking securely with online payment options.</p>
      </div>
    </section>

    <div class="vi">
      <video src="../../images/Destination (1).mp4" poster="Tourist Reservation System destinations to book" controls
        height="600" autoplay class="video"></video>
    </div>
  </section>

  <div class="section">
    <div class="container">
      <div class="booking-wrapper">
        <div class="row">
          <div class="info">
            <h1 class="main-heading">Book Your Tour Online</h1>
            <p class="description">Secure your tour with just a few clicks, enjoy a seamless experience.</p>
            <a class="button-outline" href="../AboutUs/AboutUs.php">About Us</a>
          </div>
          <div class="form-container">
            <h1 class="main-heading">Book A Tour Now</h1>
          </div>
        </div>
      </div>
    </div>
  </div>
  <form id="booking-form" action="bookingdb.php" method="POST">
    <div class="form-row">
      <!-- Full Name Input -->
      <div class="form-group">
        <input type="text" class="form-input" id="name" placeholder="Your Full Name" name="fullname"
          value="<?php echo $_SESSION['name'] ?? ''; ?>" required onkeypress="validateName()" />
        <span id="name-error" class="error-message"></span>
      </div>

      <!-- Email Input -->
      <div class="form-group">
        <input type="email" class="form-input" id="email" placeholder="Your Email Address" name="email"
          value="<?php echo $_SESSION['email'] ?? ''; ?>" required onkeypress="validateEmail()" />
        <span id="email-evali" class="error-message"></span>
      </div>

      <!-- Date Input -->
      <div class="form-group">
        <input type="date" class="form-input" id="datetime" name="date" required />
        <span id="date-error" class="error-message"></span>
      </div>

      <!-- Destination Selection -->
      <div class="form-group">
        <select class="form--destination" id="destination" name="destination" required
          onkeypress="validateDestination()" onchange="updateAmount()">
          <option value="" disabled selected>Select Destination</option>
          <optgroup label="Historical Heritage">
            <option value="Abbajifar">Abba Jifar Palace</option>
            <option value="Harar">Harar Jugol</option>
            <option value="Lalibela">Lalibela</option>
            <option value="Konso">Konso Cultural Landscape</option>
          </optgroup>
          <optgroup label="Natural Resources">
            <option value="ErtaAle">Erta Ale</option>
            <option value="Bale">Bale Mountains</option>
            <option value="Wonchi">Wonchi Lake</option>
            <option value="BlueNile">Blue Nile Fall</option>
            <option value="SofOmar">Sof-Omar Cave</option>
          </optgroup>
          <optgroup label="National Parks">
            <option value="Awash">Awash</option>
            <option value="Gambella">Gambella</option>
            <option value="Abijata">Abijatta-Shalla</option>
            <option value="Semien">Semien Mountains</option>
          </optgroup>
        </select>
        <span id="destination-error" class="error-message"></span>
      </div>

      <!-- Tour Package Selection -->
      <div class="content">
        <strong>Select Tour Package:</strong>
        <select id="tour-options" name="tourPackage" onchange="updateAmount()" required>
          <option value="" disabled selected>Select Tour Package</option>
        </select>

        <strong>Payment Method:</strong>
        <select id="payment-options" name="paymentMethod" required>
          <option value="credit-card">Credit Card</option>
          <option value="paypal">PayPal</option>
          <option value="bank-transfer">Bank Transfer</option>
        </select>

        <div class="amount">
          <input type="number" name="amount" id="amount" readonly placeholder="Total Amount">
        </div>
      </div>

      <!-- Special Requests -->
      <div class="form-group full-width">
        <textarea id="special-request" placeholder="Any Special Requests or Requirements"
          name="special_requests"></textarea>
      </div>

      <!-- Submit Button -->
      <div class="form-group full-width">
        <button class="button-submit" type="submit" id="submit-btn">Book Your Tour Now</button>
      </div>
    </div>
  </form>

  <script>
  const destinationPackages = {
    "Abbajifar": {
      "Monthly Package": 15000,
      "Weekly Package": 1500,
      "Daily Package": 250
    },
    "Harar": {
      "Monthly Package": 13000,
      "Weekly Package": 1300,
      "Daily Package": 200
    },
    "Lalibela": {
      "Monthly Package": 14000,
      "Weekly Package": 1400,
      "Daily Package": 220
    },
    "Konso": {
      "Monthly Package": 16000,
      "Weekly Package": 1600,
      "Daily Package": 280
    },
    "ErtaAle": {
      "Monthly Package": 20000,
      "Weekly Package": 2000,
      "Daily Package": 350
    },
    "Bale": {
      "Monthly Package": 18000,
      "Weekly Package": 1800,
      "Daily Package": 300
    },
    "Wonchi": {
      "Monthly Package": 12000,
      "Weekly Package": 1200,
      "Daily Package": 220
    },
    "BlueNile": {
      "Monthly Package": 15000,
      "Weekly Package": 1500,
      "Daily Package": 250
    },
    "SofOmar": {
      "Monthly Package": 17000,
      "Weekly Package": 1700,
      "Daily Package": 290
    },
    "Awash": {
      "Monthly Package": 14000,
      "Weekly Package": 1400,
      "Daily Package": 240
    },
    "Gambella": {
      "Monthly Package": 13000,
      "Weekly Package": 1300,
      "Daily Package": 220
    },
    "Abijata": {
      "Monthly Package": 12000,
      "Weekly Package": 1200,
      "Daily Package": 200
    },
    "Semien": {
      "Monthly Package": 15000,
      "Weekly Package": 1500,
      "Daily Package": 250
    }
  };

  function updateAmount() {
    const destination = document.getElementById("destination").value;
    const tourPackageSelect = document.getElementById("tour-options");
    const amountInput = document.getElementById("amount");

    // Clear any previous options
    tourPackageSelect.innerHTML = '<option value="" disabled selected>Select Tour Package</option>';

    if (destination) {
      // Get packages based on selected destination
      const packages = destinationPackages[destination];

      // Populate tour package options
      for (const [packageName, price] of Object.entries(packages)) {
        const option = document.createElement("option");
        option.value = price;
        option.textContent = `${packageName} = ${price}$`;
        tourPackageSelect.appendChild(option);
      }
    }

    // Add event listener to update amount when a package is selected
    tourPackageSelect.addEventListener("change", function() {
      const selectedPackagePrice = parseFloat(tourPackageSelect.value);
      if (!isNaN(selectedPackagePrice)) {
        amountInput.value = selectedPackagePrice.toFixed(2);
      } else {
        amountInput.value = "";
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function() {
    updateAmount();
  });
  </script>

</body>

<?php include '../common/footer.php'; ?>