<?php

// session_start();  

include '../../databases for tourist reservation sytem/dbconnection.php';


$fullName = htmlspecialchars($_POST['fullname'] ?? '');
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$booking_date = $_POST['date'] ?? '';
$destination = htmlspecialchars($_POST['destination'] ?? '');
$amount = filter_var($_POST['amount'] ?? '', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$tourPackage = htmlspecialchars($_POST['tourPackage'] ?? '');  
$special_request = htmlspecialchars($_POST['special_requests'] ?? ''); 

if (!$fullName || !$email || !$booking_date || !$destination || !$tourPackage || !$amount) {
    echo "Error: Missing required fields. Please fill out all fields correctly.";
    exit;
}


function generateTicketNumber() {
    return 'TICKET' . bin2hex(random_bytes(6));
}


$ticket_no = generateTicketNumber();


$stmt = $con->prepare("INSERT INTO booking (Ticket_no, Full_name, Email, Date, Destination, Amount, Package, Payment,Special_request) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, Paid,?)");
$stmt->bind_param("ssssssss", $ticket_no, $fullName, $email, $booking_date, $destination, $amount, $tourPackage, $special_request);


if ($stmt->execute()) {
    
    $_SESSION['booking'] = 'booked';
    $_SESSION['name'] = $fullName;
    $_SESSION['email'] = $email;
    $_SESSION['date'] = $booking_date;
    $_SESSION['special_request'] = $special_request;
    $_SESSION['ticket_no'] = $ticket_no; 

    echo "Booking successful. Your ticket number is: " . $ticket_no;
} else {
   
    echo "Error: " . $stmt->error;
}


$stmt->close();
$con->close();