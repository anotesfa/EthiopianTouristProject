<?php
include 'dbconnection.php';
// include '../Tourist_project_2024/common/header.php';
// include '../Tourist_project_2024/Distination.html/destination.php';?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Filetered Locations</title>
  <link rel="stylesheet" href="../Tourist_project_2024/CSS/destination.css">
</head>

<body>

</body>

</html>


<?php
 if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['category'])) { 
    // Sanitize the user input
  $category=mysqli_real_escape_string($con, $_POST['category']); 
  $categoryMap=[ 
    'historical'=> 'Historical Heritage',
  'natural' => 'Natural Resource',
  'national' => 'National Park'
  ];




  $sql = "SELECT * FROM locations WHERE catagory = '{$categoryMap[$category]}'";
  $filter = mysqli_query($con, $sql);

  if (mysqli_num_rows($filter) > 0) {
  // Display filtered locations
  while ($row = mysqli_fetch_assoc($filter)) {
  // Convert binary image data to base64 (if available)
  $imageSrc = !empty($row['loc_img']) ? 'data:image/jpeg;base64,' . base64_encode($row['loc_img']) :
  'default-image.jpg';

  echo '
  <div class="box filter-box" >
    <img src="' . $imageSrc . '" alt="' . htmlspecialchars($row['title']) . ' width=" 400px" height="400px" ">
                <div class=" content">
    <h1>' . htmlspecialchars($row['title']) . '</h1>
    <p>' . htmlspecialchars($row['description']) . '</p>
    <button class="button read-more">Read more</button>
    <a href="#" class="button">Make your choice</a>
  </div>
  </div>';
  }
  } else {
  echo '<p>No destinations found for the selected category.</p>';
  }
  } else {
  echo '<p>Please select a category.</p>';
  }