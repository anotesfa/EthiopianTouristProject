<?php

$username = 'root';
$hostname= 'localhost';
$password = '';

$con =mysqli_connect($hostname,$username,$password);

$db =mysqli_select_db($con, 'touristdatabase');