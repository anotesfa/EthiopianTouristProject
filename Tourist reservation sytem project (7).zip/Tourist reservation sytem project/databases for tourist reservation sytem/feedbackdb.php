<?php
session_start();
include('dbconnection.php');

$fullName =$_POST['fullname'];
$email =$_POST['email'];
$Subject =$_POST['date'];
$feedback =$_POST['destination'];



$sql = "INSERT INTO feedback values('$fullName', '$email', '$Subject','feedback')";

$result=mysqli_query($con, $sql);

if (mysqli_affected_rows($con) >= 1) {

$_SESSION['seccessful']= "Feedback sucessful send";

} else {

  $_SESSION['unsuccessful']= "Feedback unsucessful";
  
}