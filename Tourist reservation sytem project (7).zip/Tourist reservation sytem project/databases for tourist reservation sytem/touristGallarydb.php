<?php
include '../../databases for tourist reservation sytem/dbconnection.php';

$gallary = [
  [
    'image' => '../../images/images/jifar.jpeg',
    'title' => 'ABBA JIFAR PALACE',
    'catagory'=>'footer',
    
],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'LALIBELA',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'AKSUM',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'HARAR JUGOL',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'BALE MOUNTAINS NATIONAL PARK',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'WENCHI CRATER LAKE',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'SIMIEN MOUNTAINS NATIONAL PARK',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'ERTALE',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'BLUE NILE FALLS',
      'catagory'=>'footer',
     
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'SOF-OMAR CAVE',
      'catagory'=>'footer',
     
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'GAMBELLA NATIONAL PARK',
      'catagory'=>'footer',
    
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'AWASH NATIONAL PARK',
      'catagory'=>'footer',
      
  ],
  [
      'image' => '../../images/images/jifar.jpeg',
      'title' => 'ABIJATTA-SHALLA',
      'catagory'=>'footer',
      
  ]
];






// foreach ($gallary as $gal) {
//   $imagelocation = $gal['image'];
//   $imageData = addslashes(file_get_contents($imagelocation));

//   $title = $gal['title'];
//   $description = $gal['description'];

  
//   $checkQuery = "SELECT COUNT(*) AS count FROM locations WHERE title = '$title'";
//   $result = mysqli_query($con, $checkQuery);
//   $row = mysqli_fetch_assoc($result);

//   if ($row['count'] == 0) {
 
//     $sql = "INSERT INTO gallary (title, loc_img) VALUES ('$title', '$description', '$imageData')";
    
//     mysqli_query($con, $sql);
//   }
// }

// $_POST['historical'];
// $_POST['natural'];
// $_POST['national'];