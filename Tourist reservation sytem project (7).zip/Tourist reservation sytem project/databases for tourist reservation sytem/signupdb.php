<?php
session_start();
include 'dbconnection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : 'M';
    $nationality = trim($_POST['nationality']);

    // Basic input validation
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        die("All fields are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    if ($password !== $confirmPassword) {
        die("Passwords do not match.");
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Handle profile picture upload (optional)
    $profilePictureData = null;
    if (isset($_FILES['profilePic']) && $_FILES['profilePic']['error'] === UPLOAD_ERR_OK) {
        $profilePictureData = file_get_contents($_FILES['profilePic']['tmp_name']);
    }

    // SQL query using prepared statements
    $sql = "INSERT INTO Users (col_username, col_email, Gender, nationality, col_password, role, col_img_data) 
            VALUES (?, ?, ?, ?, ?, 'Tourist', ?)";

    if ($stmt = mysqli_prepare($con, $sql)) {
        mysqli_stmt_bind_param($stmt, "sssssb", $username, $email, $gender, $nationality, $hashedPassword, $profilePictureData);

        if (mysqli_stmt_execute($stmt)) {
            // Registration success
            header("Location: ../Tourist_project_2024/register.html/success.php");
            exit();
        } else {
            error_log("Error executing statement: " . mysqli_error($con));
            die("An error occurred. Please try again later.");
        }
       
    } else {
        error_log("Error preparing statement: " . mysqli_error($con));
        die("Database error. Please try again later.");
    }

   
} else {
    die("Invalid request method.");
}