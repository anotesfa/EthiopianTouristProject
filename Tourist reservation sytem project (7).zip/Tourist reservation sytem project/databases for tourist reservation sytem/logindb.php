<?php
session_start();
include('dbconnection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = $_POST['password'];

    // Use prepared statement to fetch user data
    $sql = $con->prepare("SELECT * FROM Users WHERE col_username = ?");
    $sql->bind_param("s", $username);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();

        // Check if the user is an admin
        if ($data['role'] === 'admin') {
            // Skip password verification for admins
            $_SESSION['username'] = $data['col_username'];
            $_SESSION['name'] = $data['col_name'] ?? null;
            $_SESSION['id'] = $data['user_id'];
            $_SESSION['role'] = $data['role'];

            if (!empty($data['col_img_data'])) {
                $_SESSION['profile_pic'] = 'data:image/jpeg;base64,' . base64_encode($data['col_img_data']);
            }

            header("Location: ../Tourist_project_2024/admin/dashboard.php");
            exit();
        } else {
            // Verify the password for non-admin users
            if (password_verify($password, $data['col_password'])) {
                $_SESSION['username'] = $data['col_username'];
                $_SESSION['name'] = $data['col_name'] ?? null;
                $_SESSION['email']=$data['col_email'];
                $_SESSION['id'] = $data['user_id'];
                $_SESSION['role'] = $data['role'];

                if (!empty($data['col_img_data'])) {
                    $_SESSION['profile_pic'] = 'data:image/jpeg;base64,' . base64_encode($data['col_img_data']);
                }

                header("Location: ../Tourist_project_2024/index.html/index.php"); // Normal User Dashboard or Home
                exit();
            } else {
                $_SESSION['logintest'] = "Incorrect password";
                header("Location: ../Tourist_project_2024/register.html/login.php");
                exit();
            }
        }
    } else {
        $_SESSION['logintest'] = "Incorrect username";
        header("Location: ../Tourist_project_2024/register.html/login.php");
        exit();
    }
}